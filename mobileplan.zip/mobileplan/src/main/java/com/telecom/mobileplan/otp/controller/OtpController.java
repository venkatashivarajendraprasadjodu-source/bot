package com.telecom.mobileplan.otp.controller;

import com.telecom.mobileplan.common.dto.ApiResponse;
import com.telecom.mobileplan.otp.dto.OtpVerifyRequestDto;
import com.telecom.mobileplan.otp.service.OtpService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/otp")
public class OtpController {

    private final OtpService otpService;

    // ✅ Constructor injection (MANDATORY)
    public OtpController(OtpService otpService) {
        this.otpService = otpService;
    }

    @PostMapping("/verify")
    public ApiResponse verifyOtp(@RequestBody OtpVerifyRequestDto dto) {
        otpService.verifyOtp(dto);
        return new ApiResponse("OTP verified successfully");
    }
}
