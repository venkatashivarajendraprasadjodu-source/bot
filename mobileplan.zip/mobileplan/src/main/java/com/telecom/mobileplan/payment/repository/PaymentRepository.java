package com.telecom.mobileplan.payment.repository;

import com.telecom.mobileplan.payment.entity.Payment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PaymentRepository extends JpaRepository<Payment, Long> {
}
