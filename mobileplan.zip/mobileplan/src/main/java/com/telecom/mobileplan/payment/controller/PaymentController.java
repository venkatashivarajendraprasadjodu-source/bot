package com.telecom.mobileplan.payment.controller;

import com.telecom.mobileplan.payment.dto.PaymentRequestDto;
import com.telecom.mobileplan.payment.dto.PaymentResponseDto;
import com.telecom.mobileplan.payment.service.PaymentService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/payments")
public class PaymentController {

    private final PaymentService service;

    public PaymentController(PaymentService service) {
        this.service = service;
    }

    @PostMapping
    public PaymentResponseDto makePayment(@RequestBody PaymentRequestDto request) {
        return service.makePayment(request);
    }
}
