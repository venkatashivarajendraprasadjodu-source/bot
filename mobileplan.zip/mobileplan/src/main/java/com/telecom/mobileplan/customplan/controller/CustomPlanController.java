package com.telecom.mobileplan.customplan.controller;

import org.springframework.web.bind.annotation.*;

import com.telecom.mobileplan.customplan.dto.CustomPlanRequestDto;
import com.telecom.mobileplan.customplan.service.CustomPlanService;

@RestController
@RequestMapping("/custom-plans")
public class CustomPlanController {

    private final CustomPlanService service;

    public CustomPlanController(CustomPlanService service) {
        this.service = service;
    }

    @PostMapping("/calculate")
    public double calculate(@RequestBody CustomPlanRequestDto request) {
        return service.calculatePrice(request);
    }
}
