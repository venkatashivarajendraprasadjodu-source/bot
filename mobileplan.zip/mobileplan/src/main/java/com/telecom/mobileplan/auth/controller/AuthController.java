package com.telecom.mobileplan.auth.controller;

import org.springframework.web.bind.annotation.*;

import com.telecom.mobileplan.auth.dto.LoginRequestDto;
import com.telecom.mobileplan.auth.dto.LoginResponseDto;
import com.telecom.mobileplan.auth.dto.RegisterRequestDto;
import com.telecom.mobileplan.auth.service.AuthService;
import com.telecom.mobileplan.common.dto.ApiResponse;
import com.telecom.mobileplan.otp.dto.OtpVerifyRequestDto;


@RestController
@RequestMapping("/auth")
public class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @PostMapping("/register")
    public String register(@RequestBody RegisterRequestDto request) {
        return authService.register(request);
    }

    @PostMapping("/login")
    public LoginResponseDto login(@RequestBody LoginRequestDto request) {
        return authService.login(request);
    }

}
