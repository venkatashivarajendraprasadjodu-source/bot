package com.telecom.mobileplan.otp.service;

import java.time.LocalDateTime;

import org.springframework.stereotype.Service;

import com.telecom.mobileplan.otp.dto.OtpVerifyRequestDto;
import com.telecom.mobileplan.otp.entity.OtpVerification;
import com.telecom.mobileplan.otp.repository.OtpVerificationRepository;
import com.telecom.mobileplan.user.entity.User;
import com.telecom.mobileplan.user.repository.UserRepository;

@Service
public class OtpServiceImpl implements OtpService {

    private final OtpVerificationRepository otpRepository;
    private final UserRepository userRepository;

    public OtpServiceImpl(OtpVerificationRepository otpRepository,
                          UserRepository userRepository) {
        this.otpRepository = otpRepository;
        this.userRepository = userRepository;
    }

    @Override
    public void verifyOtp(OtpVerifyRequestDto request) {

        // 1. Fetch latest OTP for email
        OtpVerification otp = otpRepository
                .findTopByEmailOrderByIdDesc(request.getEmail())
                .orElseThrow(() -> new RuntimeException("OTP not found"));

        // 2. Validate OTP
        if (!otp.getOtp().equals(request.getOtp())) {
            throw new RuntimeException("Invalid OTP");
        }

        // 3. Check expiry
        if (otp.getExpiryTime().isBefore(LocalDateTime.now())) {
            throw new RuntimeException("OTP expired");
        }

        // 4. Mark OTP verified
        otp.setVerified(true);
        otpRepository.save(otp);

        // 5. Activate USER
        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new RuntimeException("User not found"));

        user.setActive(true);
        userRepository.save(user);
    }
}
