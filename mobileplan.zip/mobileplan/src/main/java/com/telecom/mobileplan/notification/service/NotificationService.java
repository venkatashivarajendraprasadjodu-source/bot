package com.telecom.mobileplan.notification.service;

public interface NotificationService {

    void sendNotification(Long userId, String title, String message);
}
