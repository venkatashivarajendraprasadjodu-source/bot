package com.telecom.mobileplan.plan.service;

import java.time.LocalDateTime;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.telecom.mobileplan.plan.dto.ChangePlanRequestDto;
import com.telecom.mobileplan.plan.entity.Plan;
import com.telecom.mobileplan.plan.repository.PlanRepository;
import com.telecom.mobileplan.planhistory.entity.PlanChangeHistory;
import com.telecom.mobileplan.planhistory.repository.PlanChangeHistoryRepository;
import com.telecom.mobileplan.user.entity.User;
import com.telecom.mobileplan.user.repository.UserRepository;

@Service
public class PlanServiceImpl implements PlanService {

    private final UserRepository userRepository;
    private final PlanRepository planRepository;
    private final PlanChangeHistoryRepository historyRepository;

    public PlanServiceImpl(UserRepository userRepository,
                           PlanRepository planRepository,
                           PlanChangeHistoryRepository historyRepository) {
        this.userRepository = userRepository;
        this.planRepository = planRepository;
        this.historyRepository = historyRepository;
    }

    @Override
    @Transactional
    public void changePlan(ChangePlanRequestDto request) {

        User user = userRepository.findById(request.getUserId())
                .orElseThrow(() -> new RuntimeException("User not found"));

        Plan newPlan = planRepository.findById(request.getNewPlanId())
                .orElseThrow(() -> new RuntimeException("Plan not found"));

        Plan oldPlan = user.getCurrentPlan();

        user.setCurrentPlan(newPlan);
        userRepository.save(user);

        PlanChangeHistory history = new PlanChangeHistory();
        history.setUserId(user.getId());
        history.setOldPlanId(oldPlan != null ? oldPlan.getId() : null);
        history.setNewPlanId(newPlan.getId());
        history.setChangedAt(LocalDateTime.now());

        historyRepository.save(history);
    }
}
