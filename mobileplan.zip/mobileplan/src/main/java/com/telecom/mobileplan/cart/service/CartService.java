package com.telecom.mobileplan.cart.service;

import com.telecom.mobileplan.cart.dto.AddToCartRequestDto;
import com.telecom.mobileplan.cart.dto.CartResponseDto;

public interface CartService {
    CartResponseDto addToCart(AddToCartRequestDto request);
    CartResponseDto viewCart(Long userId);
}
