package com.telecom.mobileplan.notification.controller;

import java.util.List;

import org.springframework.web.bind.annotation.*;

import com.telecom.mobileplan.notification.entity.Notification;
import com.telecom.mobileplan.notification.repository.NotificationRepository;

@RestController
@RequestMapping("/notifications")
public class NotificationController {

    private final NotificationRepository notificationRepository;

    public NotificationController(NotificationRepository notificationRepository) {
        this.notificationRepository = notificationRepository;
    }

    @GetMapping("/{userId}")
    public List<Notification> getUserNotifications(@PathVariable Long userId) {
        return notificationRepository.findByUserIdOrderByCreatedAtDesc(userId);
    }
}
