package com.telecom.mobileplan.auth.service;

import java.time.LocalDateTime;
import java.util.Random;

import org.springframework.stereotype.Service;

import com.telecom.mobileplan.auth.dto.LoginRequestDto;
import com.telecom.mobileplan.auth.dto.LoginResponseDto;
import com.telecom.mobileplan.auth.dto.RegisterRequestDto;
import com.telecom.mobileplan.otp.entity.OtpVerification;
import com.telecom.mobileplan.otp.repository.OtpVerificationRepository;
import com.telecom.mobileplan.user.entity.User;
import com.telecom.mobileplan.user.repository.UserRepository;

@Service
public class AuthServiceImpl implements AuthService {

    private final UserRepository userRepository;
    private final OtpVerificationRepository otpRepository;

    public AuthServiceImpl(UserRepository userRepository,
                           OtpVerificationRepository otpRepository) {
        this.userRepository = userRepository;
        this.otpRepository = otpRepository;
    }

    @Override
    public String register(RegisterRequestDto request) {

        if (userRepository.findByEmail(request.getEmail()).isPresent()) {
            throw new RuntimeException("User already exists with this email");
        }

        User user = new User();
        user.setEmail(request.getEmail());
        user.setMobileNumber(request.getMobileNumber());
        user.setPassword(request.getPassword());
        user.setActive(false);
        userRepository.save(user);

        String otp = String.valueOf(100000 + new Random().nextInt(900000));
        System.out.println("OTP for " + request.getEmail() + " is: " + otp);

        OtpVerification otpEntity = new OtpVerification();
        otpEntity.setEmail(request.getEmail());
        otpEntity.setOtp(otp);
        otpEntity.setExpiryTime(LocalDateTime.now().plusMinutes(5));
        otpEntity.setVerified(false);

        otpRepository.save(otpEntity);

        return "OTP sent successfully";
    }

    @Override
    public LoginResponseDto login(LoginRequestDto request) {

        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new RuntimeException("User not found"));

        if (!user.getPassword().equals(request.getPassword())) {
            throw new RuntimeException("Invalid credentials");
        }

        if (!user.isActive()) {
            throw new RuntimeException("User not verified");
        }
        return new LoginResponseDto("Login successful", user.getId());
    }
}
