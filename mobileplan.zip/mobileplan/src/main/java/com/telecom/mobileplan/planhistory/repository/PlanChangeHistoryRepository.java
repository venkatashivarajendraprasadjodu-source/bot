package com.telecom.mobileplan.planhistory.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.telecom.mobileplan.planhistory.entity.PlanChangeHistory;

public interface PlanChangeHistoryRepository
        extends JpaRepository<PlanChangeHistory, Long> {
}
