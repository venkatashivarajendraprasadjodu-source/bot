package com.telecom.mobileplan.order.service;

import com.telecom.mobileplan.cart.entity.Cart;
import com.telecom.mobileplan.cart.repository.CartRepository;
import com.telecom.mobileplan.order.dto.CreateOrderRequestDto;
import com.telecom.mobileplan.order.dto.OrderResponseDto;
import com.telecom.mobileplan.order.entity.Order;
import com.telecom.mobileplan.order.enums.OrderStatus;
import com.telecom.mobileplan.order.repository.OrderRepository;
import com.telecom.mobileplan.user.entity.User;
import com.telecom.mobileplan.user.repository.UserRepository;
import org.springframework.stereotype.Service;

@Service
public class OrderServiceImpl implements OrderService {

    private final OrderRepository orderRepo;
    private final CartRepository cartRepo;
    private final UserRepository userRepo;

    public OrderServiceImpl(
            OrderRepository orderRepo,
            CartRepository cartRepo,
            UserRepository userRepo) {
        this.orderRepo = orderRepo;
        this.cartRepo = cartRepo;
        this.userRepo = userRepo;
    }

    @Override
    public OrderResponseDto createOrder(CreateOrderRequestDto request) {

        User user = userRepo.findById(request.getUserId())
                .orElseThrow(() -> new RuntimeException("User not found"));

        Cart cart = cartRepo.findByUser(user)
                .orElseThrow(() -> new RuntimeException("Cart is empty"));

        Order order = new Order();
        order.setUser(user);
        order.setPlan(cart.getPlan());
        order.setBasePrice(cart.getBasePrice());
        order.setDiscount(cart.getDiscount());
        order.setFinalPrice(cart.getFinalPrice());
        order.setStatus(OrderStatus.CREATED);

        orderRepo.save(order);

        cartRepo.delete(cart);

        OrderResponseDto response = new OrderResponseDto();
        response.setOrderId(order.getId());
        response.setPlanName(order.getPlan().getPlanName());
        response.setFinalPrice(order.getFinalPrice());
        response.setStatus(order.getStatus().name()); // ✅ FIX

        return response;
    }
}
