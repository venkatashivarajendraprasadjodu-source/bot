package com.telecom.mobileplan.activation.controller;

import org.springframework.web.bind.annotation.*;

import com.telecom.mobileplan.activation.service.ActivationService;

@RestController
@RequestMapping("/activation")
public class ActivationController {

    private final ActivationService activationService;

    public ActivationController(ActivationService activationService) {
        this.activationService = activationService;
    }

    @PostMapping("/order/{orderId}")
    public String activateOrder(@PathVariable Long orderId) {
        activationService.activateOrder(orderId);
        return "Plan activated successfully";
    }
}
