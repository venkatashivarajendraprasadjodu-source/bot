package com.telecom.mobileplan.activation.service;

import com.telecom.mobileplan.activation.service.ActivationService;
import com.telecom.mobileplan.notification.entity.Notification;
import com.telecom.mobileplan.notification.repository.NotificationRepository;
import com.telecom.mobileplan.order.entity.Order;
import com.telecom.mobileplan.order.enums.OrderStatus;
import com.telecom.mobileplan.order.repository.OrderRepository;
import com.telecom.mobileplan.plan.entity.Plan;
import com.telecom.mobileplan.user.entity.User;
import com.telecom.mobileplan.user.repository.UserRepository;
import org.springframework.stereotype.Service;

@Service
public class ActivationServiceImpl implements ActivationService {

    private final OrderRepository orderRepository;
    private final UserRepository userRepository;
    private final NotificationRepository notificationRepository;

    public ActivationServiceImpl(OrderRepository orderRepository,
                                 UserRepository userRepository,
                                 NotificationRepository notificationRepository) {
        this.orderRepository = orderRepository;
        this.userRepository = userRepository;
        this.notificationRepository = notificationRepository;
    }

    @Override
    public void activateOrder(Long orderId) {

        // 1️⃣ Fetch order
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found"));

        // 2️⃣ Get user & plan FROM ORDER (IMPORTANT)
        User user = order.getUser();
        Plan plan = order.getPlan();

        // 3️⃣ Activate plan for user
        user.setCurrentPlan(plan);
        userRepository.save(user);

        // 4️⃣ Update order status
        order.setStatus(OrderStatus.ACTIVATED);
        orderRepository.save(order);

        // 5️⃣ Create notification
        Notification notification = new Notification();
        notification.setUserId(user.getId());
        notification.setMessage("Your plan '" + plan.getPlanName() + "' is activated successfully");

        notificationRepository.save(notification);
    }
}
