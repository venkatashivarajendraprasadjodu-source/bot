package com.telecom.mobileplan.order.controller;

import com.telecom.mobileplan.order.dto.CreateOrderRequestDto;
import com.telecom.mobileplan.order.dto.OrderResponseDto;
import com.telecom.mobileplan.order.service.OrderService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/orders")
public class OrderController {

    private final OrderService service;

    public OrderController(OrderService service) {
        this.service = service;
    }

    @PostMapping
    public OrderResponseDto createOrder(@RequestBody CreateOrderRequestDto request) {
        return service.createOrder(request);
    }
}
