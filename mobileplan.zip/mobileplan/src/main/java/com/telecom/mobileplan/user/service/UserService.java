package com.telecom.mobileplan.user.service;

import com.telecom.mobileplan.user.entity.User;

public interface UserService {
    User findById(Long id);
    User save(User user);
}
