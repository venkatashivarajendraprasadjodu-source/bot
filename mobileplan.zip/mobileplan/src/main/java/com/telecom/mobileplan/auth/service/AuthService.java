package com.telecom.mobileplan.auth.service;

import com.telecom.mobileplan.auth.dto.LoginRequestDto;
import com.telecom.mobileplan.auth.dto.LoginResponseDto;
import com.telecom.mobileplan.auth.dto.RegisterRequestDto;

public interface AuthService {

    String register(RegisterRequestDto request);

    LoginResponseDto login(LoginRequestDto request);
}
