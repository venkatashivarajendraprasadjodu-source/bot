package com.telecom.mobileplan.plan.dto;

public class ChangePlanRequestDto {

    private Long userId;
    private Long newPlanId;

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getNewPlanId() {
        return newPlanId;
    }

    public void setNewPlanId(Long newPlanId) {
        this.newPlanId = newPlanId;
    }
}
