package com.telecom.mobileplan.promotion.controller;

import com.telecom.mobileplan.promotion.dto.PromotionResponseDto;
import com.telecom.mobileplan.promotion.service.PromotionService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/promotions")
public class PromotionController {

    private final PromotionService service;

    public PromotionController(PromotionService service) {
        this.service = service;
    }

    @GetMapping("/active")
    public List<PromotionResponseDto> getActivePromotions() {
        return service.getActivePromotions();
    }
}
