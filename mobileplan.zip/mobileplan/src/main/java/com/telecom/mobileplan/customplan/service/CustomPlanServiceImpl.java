package com.telecom.mobileplan.customplan.service;

import org.springframework.stereotype.Service;

import com.telecom.mobileplan.customplan.dto.CustomPlanRequestDto;

@Service
public class CustomPlanServiceImpl implements CustomPlanService {

    @Override
    public double calculatePrice(CustomPlanRequestDto request) {

        double basePrice = 399; // mock base

        basePrice += request.getExtraDataGb() * 20;
        basePrice += request.getExtraSms() * 1;

        if (request.isInternationalRoaming()) {
            basePrice += 149;
        }

        return basePrice;
    }
}
