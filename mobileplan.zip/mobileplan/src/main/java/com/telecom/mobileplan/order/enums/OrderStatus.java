package com.telecom.mobileplan.order.enums;

public enum OrderStatus {
    CREATED,
    SUCCESS,
    ACTIVATED,
    FAILED,
    PAID
}
