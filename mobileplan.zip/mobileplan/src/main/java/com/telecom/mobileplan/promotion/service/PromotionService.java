package com.telecom.mobileplan.promotion.service;

import com.telecom.mobileplan.promotion.dto.PromotionResponseDto;

import java.util.List;

public interface PromotionService {
    List<PromotionResponseDto> getActivePromotions();
}
