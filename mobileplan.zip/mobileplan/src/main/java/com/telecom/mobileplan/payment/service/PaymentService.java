package com.telecom.mobileplan.payment.service;

import com.telecom.mobileplan.payment.dto.PaymentRequestDto;
import com.telecom.mobileplan.payment.dto.PaymentResponseDto;

public interface PaymentService {
    PaymentResponseDto makePayment(PaymentRequestDto request);
}
