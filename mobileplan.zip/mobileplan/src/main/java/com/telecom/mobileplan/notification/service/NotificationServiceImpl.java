package com.telecom.mobileplan.notification.service;

import java.time.LocalDateTime;

import org.springframework.stereotype.Service;

import com.telecom.mobileplan.notification.entity.Notification;
import com.telecom.mobileplan.notification.repository.NotificationRepository;

@Service
public class NotificationServiceImpl implements NotificationService {

    private final NotificationRepository notificationRepository;

    public NotificationServiceImpl(NotificationRepository notificationRepository) {
        this.notificationRepository = notificationRepository;
    }

    @Override
    public void sendNotification(Long userId, String title, String message) {

        Notification notification = new Notification();
        notification.setUserId(userId);
        notification.setTitle(title);
        notification.setMessage(message);
        notification.setCreatedAt(LocalDateTime.now());

        notificationRepository.save(notification);
    }

}
