package com.telecom.mobileplan.cart.dto;

public class AddToCartRequestDto {

    private Long userId;
    private Long planId;
    private Long promotionId; // optional

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public Long getPlanId() { return planId; }
    public void setPlanId(Long planId) { this.planId = planId; }

    public Long getPromotionId() { return promotionId; }
    public void setPromotionId(Long promotionId) { this.promotionId = promotionId; }
}
