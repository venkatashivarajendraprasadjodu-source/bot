package com.telecom.mobileplan.cart.controller;

import com.telecom.mobileplan.cart.dto.AddToCartRequestDto;
import com.telecom.mobileplan.cart.dto.CartResponseDto;
import com.telecom.mobileplan.cart.service.CartService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/cart")
public class CartController {

    private final CartService service;

    public CartController(CartService service) {
        this.service = service;
    }

    @PostMapping("/add")
    public CartResponseDto addToCart(@RequestBody AddToCartRequestDto request) {
        return service.addToCart(request);
    }

    @GetMapping("/{userId}")
    public CartResponseDto viewCart(@PathVariable Long userId) {
        return service.viewCart(userId);
    }
}
