package com.telecom.mobileplan.plan.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.telecom.mobileplan.plan.dto.ChangePlanRequestDto;
import com.telecom.mobileplan.plan.entity.Plan;
import com.telecom.mobileplan.plan.repository.PlanRepository;
import com.telecom.mobileplan.plan.service.PlanService;

@RestController
@RequestMapping("/plans")
public class PlanController {

    private final PlanService planService;
    private final PlanRepository planRepository;

    public PlanController(PlanService planService,
                          PlanRepository planRepository) {
        this.planService = planService;
        this.planRepository = planRepository;
    }

    @GetMapping
    public List<Plan> getActivePlans() {
        return planRepository.findByActiveTrue();
    }

    @PostMapping("/change")
    public ResponseEntity<String> changePlan(
            @RequestBody ChangePlanRequestDto request) {

        planService.changePlan(request);
        return ResponseEntity.ok("Plan changed successfully");
    }
}
