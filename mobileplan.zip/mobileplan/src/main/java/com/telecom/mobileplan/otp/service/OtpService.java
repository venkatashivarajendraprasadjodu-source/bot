package com.telecom.mobileplan.otp.service;

import com.telecom.mobileplan.otp.dto.OtpVerifyRequestDto;

public interface OtpService {
    void verifyOtp(OtpVerifyRequestDto dto);
}
