package com.telecom.mobileplan.order.repository;

import com.telecom.mobileplan.order.entity.Order;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OrderRepository extends JpaRepository<Order, Long> {
}
