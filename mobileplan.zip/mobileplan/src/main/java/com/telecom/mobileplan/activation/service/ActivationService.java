package com.telecom.mobileplan.activation.service;

public interface ActivationService {

    void activateOrder(Long orderId);
}
