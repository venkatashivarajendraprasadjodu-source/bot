package com.telecom.mobileplan.payment.dto;

public class PaymentRequestDto {
    private Long orderId;
    private double amount;
    private String method; // e.g. "UPI", "CARD", "WALLET"

    public Long getOrderId() { return orderId; }
    public void setOrderId(Long orderId) { this.orderId = orderId; }

    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }

    public String getMethod() { return method; }
    public void setMethod(String method) { this.method = method; }
}
