package com.telecom.mobileplan.cart.service;

import com.telecom.mobileplan.cart.dto.AddToCartRequestDto;
import com.telecom.mobileplan.cart.dto.CartResponseDto;
import com.telecom.mobileplan.cart.entity.Cart;
import com.telecom.mobileplan.cart.repository.CartRepository;
import com.telecom.mobileplan.plan.entity.Plan;
import com.telecom.mobileplan.plan.repository.PlanRepository;
import com.telecom.mobileplan.promotion.entity.Promotion;
import com.telecom.mobileplan.promotion.repository.PromotionRepository;
import com.telecom.mobileplan.user.entity.User;
import com.telecom.mobileplan.user.repository.UserRepository;
import org.springframework.stereotype.Service;

@Service
public class CartServiceImpl implements CartService {

    private final CartRepository cartRepo;
    private final UserRepository userRepo;
    private final PlanRepository planRepo;
    private final PromotionRepository promoRepo;

    public CartServiceImpl(
            CartRepository cartRepo,
            UserRepository userRepo,
            PlanRepository planRepo,
            PromotionRepository promoRepo) {

        this.cartRepo = cartRepo;
        this.userRepo = userRepo;
        this.planRepo = planRepo;
        this.promoRepo = promoRepo;
    }

    @Override
    public CartResponseDto addToCart(AddToCartRequestDto request) {

        User user = userRepo.findById(request.getUserId())
                .orElseThrow(() -> new RuntimeException("User not found"));

        Plan plan = planRepo.findById(request.getPlanId())
                .orElseThrow(() -> new RuntimeException("Plan not found"));

        Cart cart = cartRepo.findByUser(user).orElse(new Cart());
        cart.setUser(user);
        cart.setPlan(plan);

        double basePrice = plan.getPrice();
        double discount = 0;

        if (request.getPromotionId() != null) {
            Promotion promo = promoRepo.findById(request.getPromotionId())
                    .orElseThrow(() -> new RuntimeException("Promotion not found"));

            if ("FLAT".equals(promo.getDiscountType())) {
                discount = promo.getDiscountValue();
            } else {
                discount = basePrice * promo.getDiscountValue() / 100;
            }
        }

        cart.setBasePrice(basePrice);
        cart.setDiscount(discount);
        cart.setFinalPrice(basePrice - discount);

        cartRepo.save(cart);

        return buildResponse(cart);
    }

    @Override
    public CartResponseDto viewCart(Long userId) {
        User user = userRepo.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        Cart cart = cartRepo.findByUser(user)
                .orElseThrow(() -> new RuntimeException("Cart is empty"));

        return buildResponse(cart);
    }

    private CartResponseDto buildResponse(Cart cart) {
        CartResponseDto dto = new CartResponseDto();
        dto.setPlanName(cart.getPlan().getPlanName());
        dto.setBasePrice(cart.getBasePrice());
        dto.setDiscount(cart.getDiscount());
        dto.setFinalPrice(cart.getFinalPrice());
        return dto;
    }
}
