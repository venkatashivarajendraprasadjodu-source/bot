package com.telecom.mobileplan.promotion.service;

import com.telecom.mobileplan.promotion.dto.PromotionResponseDto;
import com.telecom.mobileplan.promotion.entity.Promotion;
import com.telecom.mobileplan.promotion.repository.PromotionRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Service
public class PromotionServiceImpl implements PromotionService {

    private final PromotionRepository repository;

    public PromotionServiceImpl(PromotionRepository repository) {
        this.repository = repository;
    }

    @Override
    public List<PromotionResponseDto> getActivePromotions() {
        List<Promotion> promotions =
                repository.findByActiveTrueAndValidTillAfter(LocalDate.now());

        List<PromotionResponseDto> response = new ArrayList<>();

        for (Promotion p : promotions) {
            PromotionResponseDto dto = new PromotionResponseDto();
            dto.setTitle(p.getTitle());
            dto.setDescription(p.getDescription());

            if ("FLAT".equals(p.getDiscountType())) {
                dto.setDiscount("₹" + p.getDiscountValue() + " OFF");
            } else {
                dto.setDiscount(p.getDiscountValue() + "% OFF");
            }

            response.add(dto);
        }
        return response;
    }
}
