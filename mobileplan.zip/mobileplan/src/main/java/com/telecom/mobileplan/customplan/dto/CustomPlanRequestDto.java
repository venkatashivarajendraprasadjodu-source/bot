package com.telecom.mobileplan.customplan.dto;

public class CustomPlanRequestDto {

    private Long basePlanId;
    private int extraDataGb;
    private int extraSms;
    private boolean internationalRoaming;

    public Long getBasePlanId() {
        return basePlanId;
    }

    public void setBasePlanId(Long basePlanId) {
        this.basePlanId = basePlanId;
    }

    public int getExtraDataGb() {
        return extraDataGb;
    }

    public void setExtraDataGb(int extraDataGb) {
        this.extraDataGb = extraDataGb;
    }

    public int getExtraSms() {
        return extraSms;
    }

    public void setExtraSms(int extraSms) {
        this.extraSms = extraSms;
    }

    public boolean isInternationalRoaming() {
        return internationalRoaming;
    }

    public void setInternationalRoaming(boolean internationalRoaming) {
        this.internationalRoaming = internationalRoaming;
    }
}
