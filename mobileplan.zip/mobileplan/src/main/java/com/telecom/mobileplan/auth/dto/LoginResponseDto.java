package com.telecom.mobileplan.auth.dto;

public class LoginResponseDto {

    private String message;
    private Long userId;

    public LoginResponseDto() {
    }

    public LoginResponseDto(String message, Long userId) {
        this.message = message;
        this.userId = userId;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }
}
