package com.telecom.mobileplan.plan.service;

import com.telecom.mobileplan.plan.dto.ChangePlanRequestDto;

public interface PlanService {
    void changePlan(ChangePlanRequestDto request);
}
