package com.telecom.mobileplan.order.service;

import com.telecom.mobileplan.order.dto.CreateOrderRequestDto;
import com.telecom.mobileplan.order.dto.OrderResponseDto;

public interface OrderService {
    OrderResponseDto createOrder(CreateOrderRequestDto request);
}
