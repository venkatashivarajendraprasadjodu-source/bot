package com.telecom.mobileplan.payment.service;

import com.telecom.mobileplan.order.entity.Order;
import com.telecom.mobileplan.order.enums.OrderStatus;
import com.telecom.mobileplan.order.repository.OrderRepository;
import com.telecom.mobileplan.payment.dto.PaymentRequestDto;
import com.telecom.mobileplan.payment.dto.PaymentResponseDto;
import org.springframework.stereotype.Service;

@Service
public class PaymentServiceImpl implements PaymentService {

    private final OrderRepository orderRepository;

    public PaymentServiceImpl(OrderRepository orderRepository) {
        this.orderRepository = orderRepository;
    }

    @Override
    public PaymentResponseDto makePayment(PaymentRequestDto request) {

        Order order = orderRepository.findById(request.getOrderId())
                .orElseThrow(() -> new RuntimeException("Order not found"));

        // --- Mock payment success flow ---
        // 1) mark order as PAID
        order.setStatus(OrderStatus.PAID);
        orderRepository.save(order);

        // 2) Prepare response (use order id as payment id for now)
        PaymentResponseDto response = new PaymentResponseDto();
        response.setPaymentId(order.getId());                  // paymentId <- orderId (POC)
        response.setAmount(request.getAmount());               // amount paid
        response.setStatus(order.getStatus().name());          // "PAID"

        return response;
    }
}
