package com.telecom.mobileplan.customplan.service;

import com.telecom.mobileplan.customplan.dto.CustomPlanRequestDto;

public interface CustomPlanService {
    double calculatePrice(CustomPlanRequestDto request);
}
